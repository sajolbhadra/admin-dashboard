import React from 'react';

const NotFound = () => {
    return (
        <div>
            <h1>The page you looking for is not found</h1>
        </div>
    );
};

export default NotFound;