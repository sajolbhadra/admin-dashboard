import React from 'react';

const Dashboard = () => {
    return (
        <div>
            <h1>Welcome to Admin Dashboard</h1>
        </div>
    );
};

export default Dashboard;